from t2k import app
app.run(debug=True)
