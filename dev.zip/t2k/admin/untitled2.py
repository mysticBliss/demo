# -*- coding: utf-8 -*-
"""
Created on Fri Jan 11 22:52:25 2019

@author: STAML
"""
import os
dirname = os.path.dirname(__file__)